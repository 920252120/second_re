# ALSTM
Attentional LSTM for text

Example:
input : "May the force be with you"

output : "force is with you"

```
Fitting...

Epoch 1/1000
1/1 [==============================] - 0s - loss: 3.9881
Epoch 2/1000
1/1 [==============================] - 0s - loss: 3.7669

.
.
.
1/1 [==============================] - 0s - loss: 0.0134
Epoch 999/1000
1/1 [==============================] - 0s - loss: 0.0133
Epoch 1000/1000
1/1 [==============================] - 0s - loss: 0.0138
force is with you
```
