# aLSTMs
Codes for paper of "Attention-based LSTM with Semantic Consistency for Videos Captioning "
